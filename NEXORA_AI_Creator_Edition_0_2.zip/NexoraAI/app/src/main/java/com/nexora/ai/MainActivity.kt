package com.nexora.ai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF080B14)
private val Panel = Color(0xFF121827)
private val Violet = Color(0xFF9277FF)
private val Cyan = Color(0xFF54D9E8)
private val Muted = Color(0xFF9AA6BD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexoraApp() }
    }
}

data class Draft(val prompt: String, val negative: String, val style: String, val ratio: String, val quality: String)

@Composable
fun NexoraApp() {
    var prompt by remember { mutableStateOf("") }
    var negative by remember { mutableStateOf("") }
    var style by remember { mutableStateOf("Photorealistic") }
    var ratio by remember { mutableStateOf("Portrait 4:5") }
    var quality by remember { mutableStateOf("High") }
    var activeTab by remember { mutableStateOf("Create") }
    var sourceImage by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Your next visual starts with an idea.") }
    var drafts by remember { mutableStateOf(listOf<Draft>()) }
    var backendUrl by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        sourceImage = it
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Violet,
        secondary = Cyan, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Night,
            bottomBar = { BottomNavigation(activeTab) { activeTab = it } }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding)
                    .padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(20.dp))
                Header { showSettings = true }
                Spacer(Modifier.height(22.dp))
                when {
                    showSettings -> SettingsScreen(backendUrl, { backendUrl = it }, { showSettings = false })
                    activeTab == "Create" -> CreateScreen(
                        prompt, { prompt = it }, negative, { negative = it },
                        style, { style = it }, ratio, { ratio = it },
                        quality, { quality = it }, sourceImage,
                        { imagePicker.launch("image/*") },
                        {
                            if (prompt.isBlank()) {
                                status = "Write a prompt before preparing a render."
                            } else {
                                drafts = listOf(Draft(prompt, negative, style, ratio, quality)) + drafts
                                status = if (backendUrl.isBlank())
                                    "Draft saved. Add your secure backend URL in Settings to enable rendering."
                                else
                                    "Draft saved. Backend connection needs implementation and testing before live rendering."
                            }
                        }, status
                    )
                    activeTab == "Gallery" -> GalleryScreen(drafts) { draft ->
                        prompt = draft.prompt; negative = draft.negative
                        style = draft.style; ratio = draft.ratio; quality = draft.quality
                        activeTab = "Create"
                    }
                    activeTab == "Explore" -> ExploreScreen { prompt = it; activeTab = "Create" }
                    else -> ProfileScreen(drafts.size) { showSettings = true }
                }
            }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Violet, Cyan)), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Flare, null, tint = Night, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column {
            Text("NEXORA", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("AI IMAGE LAB", color = Cyan, fontSize = 9.sp, letterSpacing = 2.4.sp)
        }
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Muted) }
    }
}

@Composable
private fun CreateScreen(
    prompt: String, onPrompt: (String) -> Unit,
    negative: String, onNegative: (String) -> Unit,
    style: String, onStyle: (String) -> Unit,
    ratio: String, onRatio: (String) -> Unit,
    quality: String, onQuality: (String) -> Unit,
    sourceImage: Uri?, onPickImage: () -> Unit,
    onPrepare: () -> Unit, status: String
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(15.dp), contentPadding = PaddingValues(bottom = 22.dp)) {
        item { HeroCard() }
        item { SectionTitle("PROMPT STUDIO", "Describe the image") }
        item {
            OutlinedTextField(
                value = prompt, onValueChange = onPrompt, modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp),
                placeholder = { Text("A cinematic editorial portrait, natural skin texture, soft window light, 85mm lens...", color = Muted) },
                colors = fieldColors(), shape = RoundedCornerShape(18.dp),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
        }
        item {
            OutlinedButton(
                onClick = { onPrompt(enhancePrompt(prompt)) },
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(13.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
            ) {
                Icon(Icons.Default.AutoFixHigh, null); Spacer(Modifier.width(8.dp))
                Text("ENHANCE PROMPT STRUCTURE")
            }
        }
        item { SectionTitle("NEGATIVE PROMPT", "Things to avoid") }
        item {
            OutlinedTextField(
                value = negative, onValueChange = onNegative, modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. blurry, low detail, watermark, distorted anatomy", color = Muted) },
                colors = fieldColors(), shape = RoundedCornerShape(16.dp), minLines = 2
            )
        }
        item { SectionTitle("VISUAL STYLE", "Choose your look") }
        item { StyleSelector(style, onStyle) }
        item { SectionTitle("CANVAS", "Aspect ratio") }
        item { ChoiceRow(listOf("Square 1:1", "Portrait 4:5", "Story 9:16", "Landscape 16:9"), ratio, onRatio) }
        item { SectionTitle("RENDER QUALITY", "Detail preference") }
        item { ChoiceRow(listOf("Standard", "High", "Ultra"), quality, onQuality) }
        item { SectionTitle("IMAGE-TO-IMAGE", "Use a reference image") }
        item {
            Surface(Modifier.fillMaxWidth().clickable(onClick = onPickImage), color = Panel, shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF293349))) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AddPhotoAlternate, null, tint = Cyan)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (sourceImage == null) "Choose reference image" else "Reference image selected", fontWeight = FontWeight.SemiBold)
                        Text("Pick an image from your device", color = Muted, fontSize = 11.sp)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
            if (sourceImage != null) Text("Selected file: ${sourceImage.lastPathSegment ?: "image"}", color = Muted, fontSize = 10.sp)
        }
        item {
            Button(onClick = onPrepare, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(17.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) {
                Icon(Icons.Default.AutoAwesome, null); Spacer(Modifier.width(9.dp))
                Text("PREPARE IMAGE REQUEST", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Text(status, color = Cyan, fontSize = 11.sp, modifier = Modifier.padding(top = 9.dp))
        }
        item { Text("Creator tools • prompt enhancer • reference picker • presets", color = Muted, fontSize = 10.sp) }
    }
}

private fun enhancePrompt(raw: String): String {
    val clean = raw.trim()
    if (clean.isEmpty()) return ""
    val additions = listOf(
        "clear subject and intentional composition",
        "realistic lighting and natural color",
        "fine material detail and believable textures",
        "professional editorial photography"
    )
    val lower = clean.lowercase()
    val missing = additions.filter { phrase -> phrase.split(" ").take(2).none { lower.contains(it) } }
    return if (missing.isEmpty()) clean else clean.trimEnd('.', ' ') + ", " + missing.joinToString(", ")
}

@Composable
private fun SettingsScreen(url: String, onUrl: (String) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SETTINGS", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("Backend connection", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Enter the HTTPS address of your own backend. Never paste a provider API key here.", color = Muted)
        OutlinedTextField(value = url, onValueChange = onUrl, modifier = Modifier.fillMaxWidth(), label = { Text("Backend base URL") }, placeholder = { Text("https://api.yourdomain.com") }, colors = fieldColors(), shape = RoundedCornerShape(14.dp), singleLine = true)
        Text("Expected endpoint: POST /v1/images. See backend/openapi-contract.md in the project.", color = Muted, fontSize = 12.sp)
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("SAVE & RETURN") }
    }
}

@Composable
private fun GalleryScreen(drafts: List<Draft>, onLoad: (Draft) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text("YOUR WORKSPACE", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("Prompt gallery", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Saved prompt drafts appear here. Generated image storage is a later backend milestone.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        if (drafts.isEmpty()) {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Collections, null, tint = Violet, modifier = Modifier.size(36.dp))
                    Text("No drafts yet", fontWeight = FontWeight.Bold)
                    Text("Create a prompt to start your gallery.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(drafts) { draft ->
                    Surface(Modifier.fillMaxWidth().clickable { onLoad(draft) }, color = Panel, shape = RoundedCornerShape(15.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Text(draft.prompt, maxLines = 3, fontWeight = FontWeight.Medium)
                            Spacer(Modifier.height(6.dp))
                            Text("${draft.style} • ${draft.ratio} • ${draft.quality}", color = Cyan, fontSize = 10.sp)
                            Text("Tap to edit this draft", color = Muted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExploreScreen(onUse: (String) -> Unit) {
    val ideas = listOf(
        "Luxury perfume bottle on black obsidian, dramatic studio lighting, realistic glass reflections",
        "Rain-soaked futuristic street at blue hour, cinematic photography, believable reflections",
        "Minimalist skincare product on travertine stone, soft daylight, premium commercial photography",
        "Mountain cabin in misty pine forest, natural atmospheric perspective, architectural photography"
    )
    Column(Modifier.fillMaxSize()) {
        Text("INSPIRATION FEED", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("Explore concepts", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Tap an idea to send it to the prompt studio.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(14.dp))
        ideas.forEachIndexed { i, idea ->
            Surface(Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { onUse(idea) }, color = Panel, shape = RoundedCornerShape(15.dp)) {
                Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("0${i + 1}", color = Violet, fontWeight = FontWeight.Black, fontSize = 19.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(idea, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.ArrowOutward, null, tint = Cyan)
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(draftCount: Int, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("CREATOR PROFILE", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
        Text("Your creative space", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("LOCAL PROMPT DRAFTS", color = Muted, fontSize = 10.sp)
                Text("$draftCount", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Cyan)
                Text("Drafts in this session", color = Muted, fontSize = 11.sp)
            }
        }
        OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Settings, null); Spacer(Modifier.width(8.dp)); Text("Backend settings") }
        Text("NEXORA AI Creator Edition • Prototype", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun HeroCard() {
    Box(Modifier.fillMaxWidth().height(145.dp).background(Brush.linearGradient(listOf(Color(0xFF29204F), Color(0xFF112D3B), Panel)), RoundedCornerShape(23.dp)).border(1.dp, Color(0xFF554B88), RoundedCornerShape(23.dp)).padding(20.dp)) {
        Column(Modifier.align(Alignment.CenterStart)) {
            Text("MAKE THE", color = Color(0xFFC7BFFF), fontSize = 11.sp, letterSpacing = 2.sp)
            Text("UNREAL", fontSize = 31.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("LOOK REAL.", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Your visual ideas, shaped with precision.", color = Color(0xFFD0D7E6), fontSize = 10.sp)
        }
        Icon(Icons.Default.AutoAwesome, null, tint = Color(0x88FFFFFF), modifier = Modifier.align(Alignment.TopEnd).size(42.dp))
    }
}

@Composable
private fun SectionTitle(kicker: String, title: String) {
    Column {
        Text(kicker, color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StyleSelector(selected: String, onSelect: (String) -> Unit) {
    val styles = listOf("Photorealistic", "Cinematic", "Product", "Fashion", "Fantasy", "Architecture")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        styles.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { item ->
                    val chosen = selected == item
                    Surface(Modifier.weight(1f).clickable { onSelect(item) }, color = if (chosen) Color(0xFF30275A) else Panel, shape = RoundedCornerShape(13.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (chosen) Violet else Color(0xFF293349))) {
                        Text(item, Modifier.padding(vertical = 13.dp, horizontal = 5.dp), fontSize = 11.sp, color = if (chosen) Color.White else Muted, fontWeight = if (chosen) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { option ->
                    val chosen = selected == option
                    Surface(Modifier.weight(1f).clickable { onSelect(option) }, color = if (chosen) Color(0xFF30275A) else Panel, shape = RoundedCornerShape(12.dp), border = androidx.compose.foundation.BorderStroke(1.dp, if (chosen) Violet else Color(0xFF293349))) {
                        Text(option, Modifier.padding(13.dp), fontSize = 11.sp, color = if (chosen) Color.White else Muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Violet, unfocusedBorderColor = Color(0xFF293349),
    focusedContainerColor = Panel, unfocusedContainerColor = Panel,
    cursorColor = Cyan, focusedTextColor = Color.White, unfocusedTextColor = Color.White
)

@Composable
private fun BottomNavigation(active: String, onSelect: (String) -> Unit) {
    NavigationBar(containerColor = Color(0xFF0D1220), contentColor = Color.White) {
        listOf("Create", "Gallery", "Explore", "Profile").forEach { item ->
            val icon = when (item) {
                "Create" -> Icons.Default.AddCircle
                "Gallery" -> Icons.Default.Collections
                "Explore" -> Icons.Default.Explore
                else -> Icons.Default.Person
            }
            NavigationBarItem(selected = active == item, onClick = { onSelect(item) }, icon = { Icon(icon, null) }, label = { Text(item, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Color(0xFF29234A), unselectedIconColor = Muted, unselectedTextColor = Muted))
        }
    }
}
