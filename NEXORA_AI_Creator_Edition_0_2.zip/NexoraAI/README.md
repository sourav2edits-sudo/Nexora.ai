# NEXORA AI - Android Creator Edition 0.2

A futuristic dark Android image-creator starter built with Kotlin and Jetpack Compose.

## Included in the Android project
- Prompt editor and negative-prompt field
- Prompt enhancement helper (local prompt-structure helper, not an LLM)
- Style, aspect-ratio and quality selectors
- Image-to-image source-image picker UI foundation
- Create / Gallery / Explore / Profile navigation
- Local generation-history model and gallery UI foundation
- Backend endpoint configuration hook and request/response contract

## Build
1. Install Android Studio.
2. Open this folder.
3. Allow Gradle sync.
4. Run on an Android device or emulator (Android 8.0 / API 26+).

## Real image generation
The Android app does not contain a provider API key. Configure a secure HTTPS backend URL
in the app's build configuration and implement the provider adapter on the server.
See `backend/openapi-contract.md`.

The current project is a source-code starter. It is not a signed APK and has not been
built or tested in Android Studio in this environment. Do not publish it as a functioning
image generator until the backend, authentication, moderation, rate limits and image storage
have been configured and tested.
