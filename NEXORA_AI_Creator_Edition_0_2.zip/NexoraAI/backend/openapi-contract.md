# NEXORA AI backend contract

The Android client is designed to call your own HTTPS backend, never a provider directly.

## POST /v1/images
Request:
```json
{
  "prompt": "A cinematic editorial portrait...",
  "negative_prompt": "plastic skin, extra fingers, text artifacts",
  "style": "Photorealistic",
  "aspect_ratio": "Portrait 4:5",
  "quality": "High",
  "source_image": null
}
```

Successful response:
```json
{
  "id": "render_123",
  "status": "completed",
  "image_url": "https://your-cdn.example/generated/render_123.webp"
}
```

For asynchronous providers, return `status: "processing"` and expose `GET /v1/images/{id}`.
The Android app must poll that endpoint with a bounded retry policy.

## Security and production requirements
- Keep provider API keys in server-side environment variables or a secrets manager.
- Require authenticated users before accepting generation jobs.
- Validate prompt length, supported aspect ratios and quality values.
- Apply provider-appropriate safety moderation before generation.
- Enforce per-user rate limits, concurrency limits and spend caps.
- Use HTTPS, short-lived signed image URLs, and avoid logging private prompts unnecessarily.
- Return structured errors such as `400 invalid_request`, `401 unauthenticated`,
  `429 rate_limited`, and `502 provider_error`.
- Do not accept arbitrary provider URLs or let clients select arbitrary upstream hosts.
- Add deletion/retention controls for uploaded source images and generated assets.

This contract is intentionally provider-neutral. A real provider adapter still needs to be
implemented and configured with valid credentials before rendering can work.
